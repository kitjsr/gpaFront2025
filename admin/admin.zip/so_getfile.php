<?php
$choice=$_GET['choice'];
if($choice==1)
{
	echo"Dear Parent/Guardian, Your child is absent today";
}
if($choice==2)
{
	echo"Dear Parent/Guardian, school will remain closed due to Summer Vacation from 18/05/2015(Monday) to 17/06/2015(Wednesday). The school will re-open on 18/06/2015(Thursday).";
}
?>